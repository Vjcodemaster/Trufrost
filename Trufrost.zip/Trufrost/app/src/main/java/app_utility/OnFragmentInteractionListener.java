package app_utility;

public interface OnFragmentInteractionListener {
    void onFragmentMessage(String sMsg, int type, String sResults, String sResult);
}
