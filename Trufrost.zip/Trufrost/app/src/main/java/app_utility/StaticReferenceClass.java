package app_utility;

public class StaticReferenceClass {

    public static final String sURL = "http://166.62.125.168:7000/api/";//"http://166.62.125.168:8040/api/";//"http://192.168.1.15:8040/api/";//"http://192.168.43.190:7000/api/";//"http://173.82.114.197:9000/api/";//"http://192.168.1.4//
    public static final String SERVER_URL = "192.168.1.34";//"192.168.43.190";//

    public static final int PORT_NO = 7000;//8040;//
    // 1:7000/api/";//"http://192.168.1.15:8040/api/";

    public static final String PRODUCT_URL = sURL + "product_information";

    public static final int NETWORK_ERROR_CODE = 9301;

    public static final int WRITE_PERMISSION_CODE = 9001;

    public static final int DEFAULT_ODOO_ID = 989819;

    public static final String DB_NAME = "Trufrost1402";//"AC-Trufrost";//"Trufrost-server2";//"Trufrost1402";//"Trufrost-Latest";//

    public static final String USER_ID = "admin";//"autochipindia505@gmail.com";//"vijay@gmail.com";//"vijay.eh4@gmail.com";//
    public static final String PASSWORD = "autochip@505";//"a";////"auto
}
